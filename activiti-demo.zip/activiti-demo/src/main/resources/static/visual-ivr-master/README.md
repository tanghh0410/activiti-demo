# 可视化IVR编辑器

![](http://p3alsaatj.bkt.clouddn.com/20180414105705_PbucQp_Jietu20180414-105646.jpeg)

# 运行
```
// 安装依赖
yarn  // 或者 npm i

// run
npm start
```