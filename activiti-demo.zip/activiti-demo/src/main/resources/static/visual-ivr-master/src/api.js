import apiConfig from './config/api.config'
import {batchCreatAjaxApi} from './util'

export default batchCreatAjaxApi(apiConfig)
