export default {
  // 节点背景id
  nodeBackgroundId: 'drop-bg'
}
