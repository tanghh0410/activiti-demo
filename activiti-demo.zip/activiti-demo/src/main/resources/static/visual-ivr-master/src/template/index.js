import Root from './Root.html'
import Exit from './Exit.html'
import Announce from './Announce.html'
import Menu from './Menu.html'
import WorkTime from './WorkTime.html'

export default {
  Root, Announce, Exit, Menu, WorkTime
}
